"""Launch the Customer Feedback Summary terminal application."""

from datetime import date
from pathlib import Path

from customer_feedback.analysis import search, summary
from customer_feedback.models import FeedbackRecord, normalize_category
from customer_feedback.reports import export_report
from customer_feedback.storage import FeedbackStore

ROOT = Path(__file__).resolve().parent
STORE = FeedbackStore(ROOT / "data" / "feedback.csv", ROOT / "data" / "feedback.json")


def ask(prompt, validator, hint=""):
    while True:
        value = input(prompt).strip()
        if hint and value.lower() == "?":
            print(hint)
            continue
        try:
            return validator(value)
        except ValueError as exc:
            print(f"Please try again: {exc}")


def required_text(value):
    if not value:
        raise ValueError("this field cannot be blank")
    if len(value) > 1000:
        raise ValueError("maximum length is 1000 characters")
    return value


def show_records(records, limit=12):
    if not records:
        print("No matching feedback records.")
        return
    print(f"\n{'ID':<12} {'DATE':<10} {'RATE':<4} {'CATEGORY':<16} {'STATUS':<12} FEEDBACK")
    print("-" * 105)
    for r in records[:limit]:
        excerpt = r.feedback.replace("\n", " ")
        if len(excerpt) > 48:
            excerpt = excerpt[:45] + "..."
        print(f"{r.customer_id[:12]:<12} {r.date:<10} {r.rating:<4} {r.category[:16]:<16} {r.status[:12]:<12} {excerpt}")
    if len(records) > limit:
        print(f"Showing {limit} of {len(records)}. Search to narrow the results.")


def show_summary(records, low_rating, low_threshold):
    data = summary(records, low_rating, low_threshold)
    print("\nEXECUTIVE SUMMARY")
    print("=" * 55)
    print(f"Responses: {data['total']} | Average rating: {data['average']:.2f}/5 | {data['status_indicator']}")
    print(f"Positive ratings (4-5): {data['positive_pct']:.1f}% | Low ratings (1-{low_rating}): {data['low_count']}")
    print("Rating distribution:")
    for rating in range(5, 0, -1):
        count = data["rating_counts"].get(rating, 0)
        print(f"  {rating} star: {'#' * count} ({count})")
    print("Categories: " + (", ".join(f"{k} ({v})" for k, v in data["categories"].most_common()) or "none"))
    print("Statuses: " + (", ".join(f"{k} ({v})" for k, v in data["statuses"].most_common()) or "none"))
    print("Frequent feedback terms: " + (", ".join(f"{w} ({n})" for w, n in data["frequent_terms"]) or "none"))
    print("Response volume: " + data["trend"])
    if data["average"] and data["average"] < low_threshold:
        print(f"WARNING: average rating is below your {low_threshold:.1f} target.")
    if data["low_count"]:
        print(f"WARNING: {data['low_count']} response(s) have a rating of {low_rating} or lower.")
    open_count = data["statuses"].get("Open", 0)
    if open_count:
        print(f"FOLLOW-UP: {open_count} feedback item(s) are still open.")


def add_record(records):
    today = date.today().isoformat()
    record = FeedbackRecord.from_dict({
        "customer_id": ask("Customer ID: ", required_text),
        "date": ask(f"Date [{today}]: ", lambda x: x or today),
        "rating": ask("Rating (1-5): ", lambda x: _rating(x)),
        "category": normalize_category(ask("Category (e.g. Delivery, Product, Staff): ", required_text)),
        "feedback": ask("Feedback: ", required_text),
        "status": ask("Status [Open / In Progress / Resolved] (default Open): ", lambda x: x or "Open")})
    if any(r.customer_id.casefold() == record.customer_id.casefold() for r in records):
        print("That customer ID already exists; record was not added.")
        return
    records.append(record)
    STORE.save(records, "json")
    STORE.save(records, "csv")
    print("Feedback saved to both local data files.")


def _rating(value):
    try:
        rating = int(value)
    except ValueError:
        raise ValueError("enter a whole number from 1 to 5") from None
    if not 1 <= rating <= 5:
        raise ValueError("rating must be from 1 to 5")
    return rating


def run():
    print("\n" + "=" * 58 + "\n  CUSTOMER FEEDBACK SUMMARY\n  Clear insights from every customer voice\n" + "=" * 58)
    records = []
    for fmt in ("json", "csv"):
        try:
            records = STORE.load(fmt)
            if records:
                break
        except ValueError as exc:
            print(f"Could not load saved {fmt.upper()} data: {exc}")
    if not STORE.json_path.exists() and not STORE.csv_path.exists():
        # Create clean starter files so a first run has a valid local schema.
        STORE.save([], "json")
        STORE.save([], "csv")
    if not records:
        print("No saved records yet. Add feedback or import a CSV to get started.")
    low_rating, low_threshold = 2, 3.0
    while True:
        print("\nMAIN MENU")
        print("1. View feedback records   2. Add a feedback record")
        print("3. Executive summary      4. Search by keyword/category")
        print("5. Import feedback CSV    6. Export summary report")
        print("7. Change warning limits  8. Switch active data file")
        print("0. Save and quit")
        choice = input("Choose an option: ").strip()
        try:
            if choice == "1":
                show_records(records)
            elif choice == "2":
                add_record(records)
            elif choice == "3":
                show_summary(records, low_rating, low_threshold)
            elif choice == "4":
                term = input("Keyword (optional): ")
                category = input("Category (optional): ")
                show_records(search(records, term, category))
            elif choice == "5":
                path = input("Path to import CSV: ").strip().strip('"')
                imported, errors = STORE.import_csv(path)
                known = {r.customer_id.casefold() for r in records}
                added = [r for r in imported if r.customer_id.casefold() not in known]
                duplicates = len(imported) - len(added)
                records.extend(added)
                STORE.save(records, "json"); STORE.save(records, "csv")
                print(f"Imported {len(added)} valid row(s); skipped {duplicates} duplicate ID(s).")
                for error in errors:
                    print("  " + error)
            elif choice == "6":
                fmt = input("Format (md / txt / csv): ").strip().lower()
                if fmt not in {"md", "txt", "csv"}:
                    print("Choose md, txt, or csv.")
                    continue
                target = ROOT / "reports" / f"feedback_summary.{fmt}"
                export_report(records, target, fmt)
                print(f"Report saved: {target}")
            elif choice == "7":
                low_rating = ask("Warn at or below rating (1-4): ", lambda x: _range(x, 1, 4))
                low_threshold = ask("Minimum average target (1.0-5.0): ", _threshold)
                print("Warning limits updated for this session.")
            elif choice == "8":
                fmt = input("Load from CSV or JSON? ").strip().lower()
                if fmt in {"csv", "json"}:
                    records = STORE.load(fmt)
                    print(f"Loaded {len(records)} records from {fmt.upper()}.")
                else:
                    print("Please enter CSV or JSON.")
            elif choice == "0":
                STORE.save(records, "json"); STORE.save(records, "csv")
                print("Saved CSV and JSON. See you next time!")
                break
            else:
                print("Choose one of the listed menu numbers.")
        except (ValueError, OSError) as exc:
            print(f"Could not complete that action: {exc}")


def _range(value, minimum, maximum):
    number = _rating(value)
    if not minimum <= number <= maximum:
        raise ValueError(f"enter a number from {minimum} to {maximum}")
    return number


def _threshold(value):
    try:
        number = float(value)
    except ValueError:
        raise ValueError("enter a number from 1.0 to 5.0") from None
    if not 1 <= number <= 5:
        raise ValueError("enter a number from 1.0 to 5.0")
    return number


if __name__ == "__main__":
    run()
