import csv
import json
import tempfile
import unittest
from pathlib import Path

from customer_feedback.analysis import search, summary
from customer_feedback.models import FeedbackRecord
from customer_feedback.reports import export_report
from customer_feedback.storage import FeedbackStore


def record(customer_id="C-1", rating=5, category="Delivery", feedback="Fast delivery and helpful updates"):
    return FeedbackRecord.from_dict({"customer_id": customer_id, "date": "2026-10-12",
        "rating": rating, "category": category, "feedback": feedback, "status": "Open"})


class ModelTests(unittest.TestCase):
    def test_rating_and_date_validation(self):
        with self.assertRaisesRegex(ValueError, "between 1 and 5"):
            record(rating=6)
        with self.assertRaisesRegex(ValueError, "YYYY-MM-DD"):
            FeedbackRecord.from_dict({**record().to_dict(), "date": "12/10/2026"})

    def test_required_fields(self):
        with self.assertRaisesRegex(ValueError, "cannot be blank"):
            FeedbackRecord.from_dict({**record().to_dict(), "feedback": " "})


class AnalysisTests(unittest.TestCase):
    def test_summary_and_warning_status(self):
        data = summary([record(rating=1), record("C-2", 5)], low_rating=2, low_threshold=3.5)
        self.assertEqual(data["total"], 2)
        self.assertEqual(data["average"], 3)
        self.assertEqual(data["low_count"], 1)
        self.assertEqual(data["status_indicator"], "Needs attention")

    def test_search_matches_keyword_and_category(self):
        rows = [record(), record("C-2", 3, "Product", "The color is excellent")]
        self.assertEqual([r.customer_id for r in search(rows, "delivery")], ["C-1"])
        self.assertEqual([r.customer_id for r in search(rows, category="prod")], ["C-2"])


class PersistenceTests(unittest.TestCase):
    def test_csv_json_round_trip(self):
        with tempfile.TemporaryDirectory() as folder:
            store = FeedbackStore(Path(folder) / "rows.csv", Path(folder) / "rows.json")
            rows = [record(), record("C-2", 4)]
            for fmt in ("csv", "json"):
                store.save(rows, fmt)
                self.assertEqual(store.load(fmt), rows)

    def test_csv_import_reports_bad_row_and_keeps_good_rows(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "input.csv"
            with path.open("w", newline="", encoding="utf-8") as stream:
                writer = csv.DictWriter(stream, fieldnames=["customer_id", "date", "rating", "category", "feedback", "status"])
                writer.writeheader(); writer.writerow(record().to_dict())
                writer.writerow({**record("C-2").to_dict(), "rating": 8})
            valid, errors = FeedbackStore(Path(folder) / "o.csv", Path(folder) / "o.json").import_csv(path)
            self.assertEqual(len(valid), 1)
            self.assertIn("Line 3", errors[0])

    def test_report_exports(self):
        with tempfile.TemporaryDirectory() as folder:
            for fmt in ("md", "txt", "csv"):
                path = Path(folder) / f"report.{fmt}"
                export_report([record()], path, fmt)
                self.assertTrue(path.exists())
                self.assertGreater(path.stat().st_size, 0)


if __name__ == "__main__":
    unittest.main()
