"""Pure functions for summaries, trends, frequent themes, and search."""

from collections import Counter
from datetime import date, timedelta
import re

STOP_WORDS = {"about", "after", "again", "also", "and", "are", "because", "been", "but", "could", "from", "have", "help", "into", "just", "more", "much", "not", "our", "that", "the", "their", "there", "they", "this", "was", "were", "with", "would", "you", "your", "very", "when", "where", "will", "still", "only", "really", "some", "service", "product", "staff", "store", "app", "team"}


def frequent_terms(records, limit=8):
    words = Counter()
    for record in records:
        tokens = re.findall(r"[a-zA-Z][a-zA-Z'-]{2,}", record.feedback.lower())
        words.update(word for word in tokens if word not in STOP_WORDS)
    return words.most_common(limit)


def summary(records, low_rating=2, low_threshold=3.0):
    total = len(records)
    ratings = [record.rating for record in records]
    average = sum(ratings) / total if total else 0.0
    counts = Counter(ratings)
    categories = Counter(record.category for record in records)
    statuses = Counter(record.status for record in records)
    low_count = sum(r <= low_rating for r in ratings)
    positive_pct = (sum(r >= 4 for r in ratings) / total * 100) if total else 0
    by_month = Counter(record.date[:7] for record in records)
    months = sorted(by_month)
    trend = "Not enough data"
    if len(months) >= 2:
        first, last = months[-2:]
        trend = f"{first}: {by_month[first]} responses -> {last}: {by_month[last]} responses"
    return {"total": total, "average": average, "rating_counts": counts,
            "categories": categories, "statuses": statuses, "low_count": low_count,
            "positive_pct": positive_pct, "frequent_terms": frequent_terms(records),
            "trend": trend, "status_indicator": "On track" if average >= low_threshold else "Needs attention",
            "low_rating_threshold": low_rating, "score_threshold": low_threshold}


def search(records, query="", category=""):
    query, category = query.strip().lower(), category.strip().lower()
    return [r for r in records if (not category or category in r.category.lower()) and
            (not query or query in " ".join((r.customer_id, r.date, r.category, r.feedback, r.status)).lower())]


def rating_trend(records):
    months = sorted({record.date[:7] for record in records})
    values = []
    for month in months:
        month_ratings = [r.rating for r in records if r.date[:7] == month]
        values.append((month, sum(month_ratings) / len(month_ratings)))
    return values
