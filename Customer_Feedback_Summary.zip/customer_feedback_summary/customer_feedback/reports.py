"""Human-readable and CSV report export."""

import csv
from pathlib import Path

from .analysis import summary
from .storage import FIELDS


def render_report(records):
    data = summary(records)
    lines = ["# Customer Feedback Executive Summary", "", f"Generated records: {data['total']}",
             f"Average rating: {data['average']:.2f} / 5", f"Status: {data['status_indicator']}",
             f"Positive ratings (4-5): {data['positive_pct']:.1f}%",
             f"Low ratings (1-{data['low_rating_threshold']}): {data['low_count']}", "",
             "## Rating breakdown", ""]
    lines.extend(f"- {rating} star: {data['rating_counts'].get(rating, 0)}" for rating in range(5, 0, -1))
    lines.extend(["", "## Feedback by category", ""])
    lines.extend(f"- {category}: {count}" for category, count in data["categories"].most_common())
    lines.extend(["", "## Frequently mentioned terms", ""])
    lines.extend(f"- {word}: {count}" for word, count in data["frequent_terms"])
    lines.extend(["", "## Recent volume trend", "", data["trend"], ""])
    return "\n".join(lines)


def export_report(records, path, fmt):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if fmt == "csv":
        data = summary(records)
        with path.open("w", newline="", encoding="utf-8") as stream:
            writer = csv.writer(stream)
            writer.writerow(["metric", "value"])
            writer.writerow(["total_records", data["total"]])
            writer.writerow(["average_rating", f"{data['average']:.2f}"])
            writer.writerow(["status", data["status_indicator"]])
            writer.writerow(["positive_percent", f"{data['positive_pct']:.1f}"])
            writer.writerow(["low_rating_count", data["low_count"]])
            for rating in range(1, 6):
                writer.writerow([f"rating_{rating}_count", data["rating_counts"].get(rating, 0)])
        return
    content = render_report(records)
    path.write_text(content if fmt == "md" else content.replace("# ", "").replace("## ", ""), encoding="utf-8")
