"""CSV and JSON storage with safe recovery from missing or malformed files."""

import csv
import json
from pathlib import Path

from .models import FeedbackRecord

FIELDS = ["customer_id", "date", "rating", "category", "feedback", "status"]


class FeedbackStore:
    def __init__(self, csv_path, json_path):
        self.csv_path, self.json_path = Path(csv_path), Path(json_path)

    def load(self, fmt="json"):
        path = self.json_path if fmt == "json" else self.csv_path
        if not path.exists():
            return []
        try:
            if fmt == "json":
                with path.open(encoding="utf-8") as stream:
                    rows = json.load(stream)
                if not isinstance(rows, list):
                    raise ValueError("JSON data must be a list of records")
            else:
                with path.open(newline="", encoding="utf-8-sig") as stream:
                    rows = list(csv.DictReader(stream))
            records, errors = [], []
            for index, row in enumerate(rows, start=1):
                try:
                    records.append(FeedbackRecord.from_dict(row))
                except (ValueError, TypeError) as exc:
                    errors.append(f"record {index}: {exc}")
            if errors and not records:
                raise ValueError("No valid records found. " + "; ".join(errors[:3]))
            return records
        except (OSError, json.JSONDecodeError, csv.Error) as exc:
            raise ValueError(f"Could not read {path.name}: {exc}") from exc

    def save(self, records, fmt="json"):
        path = self.json_path if fmt == "json" else self.csv_path
        path.parent.mkdir(parents=True, exist_ok=True)
        if fmt == "json":
            with path.open("w", encoding="utf-8") as stream:
                json.dump([record.to_dict() for record in records], stream,
                          indent=2, ensure_ascii=False)
                stream.write("\n")
        else:
            with path.open("w", newline="", encoding="utf-8") as stream:
                writer = csv.DictWriter(stream, fieldnames=FIELDS)
                writer.writeheader()
                writer.writerows(record.to_dict() for record in records)

    def import_csv(self, source_path):
        """Return valid records and a list of line-numbered import errors."""
        valid, errors = [], []
        try:
            with Path(source_path).open(newline="", encoding="utf-8-sig") as stream:
                reader = csv.DictReader(stream)
                missing = set(FIELDS[:-1]) - set(reader.fieldnames or [])
                if missing:
                    return [], ["Header is missing: " + ", ".join(sorted(missing))]
                for line, row in enumerate(reader, start=2):
                    try:
                        valid.append(FeedbackRecord.from_dict(row))
                    except (ValueError, TypeError) as exc:
                        errors.append(f"Line {line}: {exc}")
        except (OSError, csv.Error) as exc:
            errors.append(f"Could not read file: {exc}")
        return valid, errors
