"""Customer Feedback Summary - a beginner-friendly feedback analyzer."""

__version__ = "1.0.0"
