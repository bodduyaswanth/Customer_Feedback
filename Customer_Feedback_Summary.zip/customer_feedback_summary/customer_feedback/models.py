"""Validated feedback records and input helpers."""

from dataclasses import dataclass
from datetime import date
import re


@dataclass(frozen=True)
class FeedbackRecord:
    customer_id: str
    date: str
    rating: int
    category: str
    feedback: str
    status: str = "Open"

    def to_dict(self):
        return {"customer_id": self.customer_id, "date": self.date,
                "rating": self.rating, "category": self.category,
                "feedback": self.feedback, "status": self.status}

    @classmethod
    def from_dict(cls, row):
        rating_value = row.get("rating", "")
        if isinstance(rating_value, bool):
            raise ValueError("rating must be a whole number from 1 to 5")
        try:
            rating = int(rating_value)
        except (TypeError, ValueError):
            raise ValueError("rating must be a whole number from 1 to 5") from None
        if str(rating_value).strip() != str(rating):
            raise ValueError("rating must be a whole number from 1 to 5")
        customer_id = _required(row.get("customer_id"), "customer_id", 40)
        raw_date = _required(row.get("date"), "date", 10)
        try:
            date.fromisoformat(raw_date)
        except ValueError:
            raise ValueError("date must use YYYY-MM-DD format") from None
        if not 1 <= rating <= 5:
            raise ValueError("rating must be between 1 and 5")
        category = _required(row.get("category"), "category", 40)
        feedback = _required(row.get("feedback"), "feedback", 1000)
        status = str(row.get("status") or "Open").strip().title()
        if status not in {"Open", "In Progress", "Resolved"}:
            raise ValueError("status must be Open, In Progress, or Resolved")
        return cls(customer_id, raw_date, rating, category, feedback, status)


def _required(value, field, max_length):
    value = str(value or "").strip()
    if not value:
        raise ValueError(f"{field} cannot be blank")
    if len(value) > max_length:
        raise ValueError(f"{field} must be {max_length} characters or fewer")
    if any(ord(char) < 32 for char in value):
        raise ValueError(f"{field} contains unsupported control characters")
    return value


def normalize_category(value):
    value = _required(value, "category", 40)
    return " ".join(word.capitalize() for word in re.split(r"\s+", value))
