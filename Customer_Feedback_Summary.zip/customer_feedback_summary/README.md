# Customer Feedback Summary

A beginner-friendly, menu-driven Python application for collecting feedback and turning it into useful customer insights. It uses only the Python standard library (Python 3.10+); no packages or internet connection are required.

## Get started

1. Install Python 3.10 or newer from [python.org](https://www.python.org/downloads/).
2. Open a terminal in this folder.
3. Start the application:

   ```text
   python main.py
   ```

The included 36-record sample is loaded from `data/feedback.json`. The program creates or updates both `data/feedback.json` and `data/feedback.csv` when you save or add records. If you switch the active source, the selected file is loaded for that session.

## Menu features

- View saved feedback in a readable table.
- Add records with validation for required fields, date format, rating (1-5), text length, status, and duplicate customer IDs.
- See an executive summary with totals, averages, rating distribution, category and status counts, frequent feedback terms, recent response-volume trend, status indicator, and warnings.
- Search feedback by keyword and/or category.
- Import legacy CSV data. Each malformed row is reported with its line number; valid rows are retained and duplicate IDs are skipped.
- Export a Markdown (`md`), plain-text (`txt`), or CSV executive summary to `reports/`.
- Adjust low-rating and average-score warning thresholds for the current session.

### Sample data and schema

The CSV and JSON samples contain the same 36 fictional records across six months. Fields are `customer_id`, `date` (`YYYY-MM-DD`), `rating` (1-5), `category`, `feedback`, and `status` (`Open`, `In Progress`, or `Resolved`). The data includes positive, neutral, and negative examples across delivery, product, staff, pricing, and returns.

For a custom CSV import, use those six column headers. The status column may be omitted; missing status defaults to `Open`.

## Run the tests

From this folder, run:

```text
python -m unittest discover -s tests -v
```

## Quick demo guide

1. Run `python main.py` and choose **3** to show the executive summary and warnings.
2. Choose **4**, search for `refund`, then filter category `Returns`.
3. Choose **2** and try rating `9` followed by `4` to see validation in action. Add a short sample record.
4. Choose **5** to import a CSV. Invalid rows show their source line number.
5. Choose **6**, export `md`, and open `reports/feedback_summary.md`.
6. Quit with **0**, relaunch, and confirm your records persist.

## Project layout

```text
customer_feedback_summary/
├── customer_feedback/       # Models, storage, analysis, and reports
├── data/                    # Paired sample CSV and JSON datasets
├── reports/                 # Exported summaries appear here
├── tests/                   # Standard-library unittest coverage
├── main.py                  # Terminal menu and application entry point
└── README.md
```

The app stores data locally and does not send it anywhere. The optional charting suggestion was kept dependency-free: the terminal summary includes an ASCII rating bar chart.
